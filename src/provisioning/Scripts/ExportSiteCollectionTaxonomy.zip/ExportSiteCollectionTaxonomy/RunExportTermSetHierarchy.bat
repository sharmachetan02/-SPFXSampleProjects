@echo off
REM Change directory to script location
cd /d %~dp0

REM Run PowerShell script with parameters
powershell.exe -ExecutionPolicy Bypass -File "ExportTermSet.ps1" ^
    -SiteUrl "https://eutelsatgroup.sharepoint.com/sites/MADB-Dev" ^
    -TermGroupName "Market Access" ^
    -TermSetName "Main Menu" ^
    -OutputJsonPath "%~dp0ExportTermSetHierarchy.json"

pause