@echo on
REM Change directory to script location
cd /d "C:\Projects\MADB_PowerShellScripts\ImportCountryGroupingTaxonomy"
@echo %~dp0
REM Run PowerShell script with parameters
@echo Script Directory: %SCRIPT_DIR%
powershell.exe -ExecutionPolicy Bypass -File "ImportCountryGroupingTaxonomy.ps1" ^
    -SiteUrl "https://eutelsatgroup.sharepoint.com/sites/MADB-Dev" ^
    -InputJsonPath "%~dp0ExportCountryGroupingTaxonomy.json" ^
    -LogFilePath "%~dp0ImportCountryGroupingTaxonomy.log"

pause