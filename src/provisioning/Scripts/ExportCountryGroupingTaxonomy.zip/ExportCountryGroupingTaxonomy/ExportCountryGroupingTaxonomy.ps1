param(
    [Parameter(Mandatory = $true)]
    [string]$SiteUrl,

    [Parameter(Mandatory = $true)]
    [string]$TermGroupName,

    [Parameter(Mandatory = $true)]
    [string]$TermSetName,

    [Parameter(Mandatory = $true)]
    [string]$OutputJsonPath,

    [Parameter(Mandatory = $true)]
    [string]$LogFilePath
)

# Function to log messages
<#function Write-Log {
    param(
        [string]$Message,
        [string]$Level = "INFO"
    )
    $timestamp = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    $logEntry = "$timestamp [$Level] $Message"
    
# Ensure directory exists
    $logDir = Split-Path $LogFilePath
    if (-not (Test-Path $logDir)) {
        New-Item -ItemType Directory -Path $logDir -Force
    }

    Add-Content -Path $LogFilePath -Value $logEntry
    Write-Host $logEntry
}#>
# Logging function
function Write-Log {
    param(
        [string]$Message,
        [ValidateSet("INFO","WARN","ERROR")]
        [string]$Level = "INFO"
    )

    # Initialize/clear log file on first use
    if (-not $script:LogInitialized) {
        $script:LogInitialized = $true

        $logDir = Split-Path $LogFilePath
        if (-not (Test-Path $logDir)) {
            New-Item -ItemType Directory -Path $logDir -Force | Out-Null
        }

        if (Test-Path $LogFilePath) {
            try {
                Clear-Content -Path $LogFilePath -ErrorAction Stop
            } catch {
                # Fallback: overwrite file with empty content
                Set-Content -Path $LogFilePath -Value $null -Force
            }
        } else {
            New-Item -Path $LogFilePath -ItemType File -Force | Out-Null
        }
    }

    $timestamp = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    $logEntry = "$timestamp [$Level] $Message"

    Add-Content -Path $LogFilePath -Value $logEntry
    Write-Host $logEntry
}
try {
    Write-Log "Connecting to SharePoint Online site: $SiteUrl"
    Connect-PnPOnline -Url $SiteUrl
    Write-Log "Connected successfully."

    # Get Term Group
    Write-Log "Fetching Term Group: $TermGroupName"
    $termGroup = Get-PnPTermGroup -Identity $TermGroupName
    if (-not $termGroup) {
        throw "Term Group '$TermGroupName' not found."
    }

    # Get Term Set
    Write-Log "Fetching Term Set: $TermSetName"
    $termSet = Get-PnPTermSet -TermGroup $termGroup -Identity $TermSetName -Includes Terms
    if (-not $termSet) {
        throw "Term Set '$TermSetName' not found."
    }

    # Recursive function to build hierarchy
    function Convert-TermToHierarchy {
        param($term)

        $childTerms = Get-PnPTerm -TermSet $termSet -TermGroup $termGroup -Identity $term.Id -Includes Terms
        $children = @()

        foreach ($child in $childTerms.Terms) {
            $children += Convert-TermToHierarchy -term $child
        }

        return [PSCustomObject]@{
            Id                    = $term.Id
            Name                  = $term.Name
            PathOfTerm            = $term.PathOfTerm
            IsAvailableForTagging = $term.IsAvailableForTagging
            LocalCustomProperties = $term.LocalCustomProperties
            Children              = $children
        }
    }

    # Build hierarchy
    Write-Log "Building term hierarchy..."
    $hierarchy = @()
    foreach ($rootTerm in $termSet.Terms) {
        $hierarchy += Convert-TermToHierarchy -term $rootTerm
    }

    $exportData = [PSCustomObject]@{
        TermGroup = $termGroup.Name
        TermSet   = $termSet.Name
        Terms     = $hierarchy
    }

    # Export to JSON
    Write-Log "Exporting hierarchy to JSON: $OutputJsonPath"
    $exportData | ConvertTo-Json -Depth 50 | Out-File $OutputJsonPath -Encoding UTF8
    Write-Log "✅ Export completed successfully."

} catch {
    Write-Log "❌ Error: $_" "ERROR"
    Write-Host "An error occurred. Check log file: $LogFilePath"
}
