@echo off
REM Change directory to script location
cd /d %~dp0

REM Run PowerShell script with parameters
powershell.exe -ExecutionPolicy Bypass -File "ExportCountryGroupingTaxonomy.ps1" ^
    -SiteUrl "https://eutelsatgroup.sharepoint.com/sites/MADB-Dev" ^
    -TermGroupName "Market Access" ^
    -TermSetName "Country Grouping" ^
    -OutputJsonPath "%~dp0ExportCountryGroupingTaxonomy.json"
    -LogFilePath "%~dp0ExportCountryGroupingTaxonomy.log"

pause