@ECHO OFF
SET "scriptDirectory=%~dp0"
SET "PowerShellScriptPath=%scriptDirectory%ExportSiteColumns.ps1"
PowerShell -NoProfile -ExecutionPolicy Bypass -Command "& '%PowerShellScriptPath%' '%scriptDirectory%'"

pause >nul