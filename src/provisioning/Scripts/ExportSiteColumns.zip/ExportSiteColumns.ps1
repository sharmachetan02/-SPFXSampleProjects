
param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [ValidateScript({ Test-Path -Path $_ })]
    [string]$scriptDirectory
)
write-host "scriptDirectory $scriptDirectory"
Connect-PnPOnline -Url https://eutelsatgroup.sharepoint.com/sites/MADB-Dev
Get-PnPProvisioningTemplate -Handlers Fields  -Out .\MA_SiteColumns.xml
$sourceXmlPath = "$scriptDirectory\MA_SiteColumns.xml"


# Load the XML
[xml]$xml = Get-Content $sourceXmlPath

# Set up namespace manager
$nsMgr = New-Object System.Xml.XmlNamespaceManager($xml.NameTable)
$nsMgr.AddNamespace("pnp", "http://schemas.dev.office.com/PnP/2020/02/ProvisioningSchema")

# Get all <Field> nodes under <pnp:SiteFields>
$fields = $xml.SelectNodes("//pnp:SiteFields/Field", $nsMgr)

# Remove any field that doesn't belong to the "Market Access" group
foreach ($field in $fields) {
    if ($field.GetAttribute("Group") -ne "Market Access") {
        $field.ParentNode.RemoveChild($field) | Out-Null
    }
}

# Save the cleaned XML
$xml.Save($sourceXmlPath)