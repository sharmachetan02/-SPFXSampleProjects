@echo off
REM Change directory to script location
cd /d %~dp0

REM Define log file path
set LogFilePath="%~dp0ImportMainMenuTaxonomy.log"
powershell.exe -ExecutionPolicy Bypass -File "ImportMainMenuTaxonomy.ps1" ^
    -SiteUrl "https://eutelsatgroup.sharepoint.com/sites/MADB-Dev" ^
    -InputJsonPath "%~dp0ExportMainMenuTaxonomy.json" ^
    -LogFilePath "%~dp0ImportMainMenuTaxonomy.log"
pause