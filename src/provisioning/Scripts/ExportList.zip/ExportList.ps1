param (
    [string]$scriptDirectory,
    [string]$listName,
	[string]$contentTypes
)
$outputFile = ".\$listName.xml"
Connect-PnPOnline -Url https://eutelsatgroup.sharepoint.com/sites/MADB-Dev
Get-PnPProvisioningTemplate -Handlers ContentTypes,Lists  -ListsToExtract $listName  -Out $outputFile
$arr = $contentTypes -split ","
[xml]$xml = Get-Content $outputFile
$nsMgr = New-Object System.Xml.XmlNamespaceManager($xml.NameTable)
$nsMgr.AddNamespace("pnp", "http://schemas.dev.office.com/PnP/2020/02/ProvisioningSchema")
$cts = $xml.SelectNodes("//pnp:ContentType", $nsMgr)

for ($i = $cts.Count - 1; $i -ge 0; $i--) {
    $internalName = $cts[$i].Attributes["Name"].Value
    if (-not($internalName -in $arr)) {
        # Remove the field from its parent node
        $cts[$i].ParentNode.RemoveChild($cts[$i]) | Out-Null
    }
}
$xml.Save($outputFile)