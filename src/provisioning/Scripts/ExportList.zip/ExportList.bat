@echo off
set "scriptDirectory=%~dp0"
set "PowerShellScriptPath=%scriptDirectory%\ExportList.ps1"
set "listName=Authority"
set "contentTypes=MA_Authority,MA_Administration,MA_Regulator,MA_Organization"
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
  "& '%PowerShellScriptPath%' -scriptDirectory '%scriptDirectory%' -listName '%listName%' -contentTypes '%contentTypes%'"

pause >nul