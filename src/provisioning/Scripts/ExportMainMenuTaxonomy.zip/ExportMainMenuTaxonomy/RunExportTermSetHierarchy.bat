@echo off
REM Change directory to script location
cd /d %~dp0

REM Define log file path
set LogFilePath="%~dp0ExportMainMenuTaxonomy.log"

REM Run PowerShell script with parameters
powershell.exe -ExecutionPolicy Bypass -File "ExportMainMenuTaxonomy.ps1" ^
    -SiteUrl "https://eutelsatgroup.sharepoint.com/sites/MADB-Dev" ^
    -TermGroupName "Market Access" ^
    -TermSetName "Main Menu" ^
    -OutputJsonPath "%~dp0ExportMainMenuTaxonomy.json" ^
    -LogFilePath %LogFilePath%

pause