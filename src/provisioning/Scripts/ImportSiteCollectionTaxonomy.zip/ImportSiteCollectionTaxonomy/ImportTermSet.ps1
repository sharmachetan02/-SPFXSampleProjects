﻿param(
    [Parameter(Mandatory = $true)]
    [string]$SiteUrl,

    [Parameter(Mandatory = $true)]
    [string]$InputJsonPath,

    [Parameter(Mandatory = $true)]
    [string]$LogFilePath
)

# Logging function
function Write-Log {
    param(
        [string]$Message,
        [ValidateSet("INFO","WARN","ERROR")]
        [string]$Level = "INFO"
    )

    # Initialize/clear log file on first use
    if (-not $script:LogInitialized) {
        $script:LogInitialized = $true

        $logDir = Split-Path $LogFilePath
        if (-not (Test-Path $logDir)) {
            New-Item -ItemType Directory -Path $logDir -Force | Out-Null
        }

        if (Test-Path $LogFilePath) {
            try {
                Clear-Content -Path $LogFilePath -ErrorAction Stop
            } catch {
                # Fallback: overwrite file with empty content
                Set-Content -Path $LogFilePath -Value $null -Force
            }
        } else {
            New-Item -Path $LogFilePath -ItemType File -Force | Out-Null
        }
    }

    $timestamp = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    $logEntry = "$timestamp [$Level] $Message"

    Add-Content -Path $LogFilePath -Value $logEntry
    Write-Host $logEntry
}

try {
    Write-Log "Connecting to SharePoint Online: $SiteUrl"
    Connect-PnPOnline -Url $SiteUrl
    Write-Log "Connected successfully."

    # Load JSON data
    if (-not (Test-Path $InputJsonPath)) {
        throw "Input JSON file not found: $InputJsonPath"
    }
    $importData = Get-Content $InputJsonPath | ConvertFrom-Json
    Write-Log "Loaded JSON data from $InputJsonPath"

    $termGroupName = $importData.TermGroup
    $newTermSetName = "$($importData.TermSet) - Copy"
    $terms = $importData.Terms

    # Get Taxonomy Session
    $ctx = Get-PnPContext
    $taxonomySession = [Microsoft.SharePoint.Client.Taxonomy.TaxonomySession]::GetTaxonomySession($ctx)
    $termStore = $taxonomySession.GetDefaultSiteCollectionTermStore()
    $ctx.Load($termStore)
    $ctx.ExecuteQuery()

    # Get or create Term Group
    try {
        $termGroup = $termStore.Groups.GetByName($termGroupName)
        $ctx.Load($termGroup)
        $ctx.ExecuteQuery()
        Write-Log "Found Term Group: $termGroupName"
    } catch {
        Write-Log "Creating Term Group: $termGroupName" "WARN"
        $termGroup = $termStore.CreateGroup($termGroupName, [System.Guid]::NewGuid())
        $ctx.ExecuteQuery()
    }

    # Get or create Term Set
    try {
        $termSet = $termGroup.TermSets.GetByName($newTermSetName)
        $ctx.Load($termSet)
        $ctx.ExecuteQuery()
        Write-Log "Found Term Set: $newTermSetName"
    } catch {
        Write-Log "Creating Term Set: $newTermSetName" "WARN"
        $termSet = $termGroup.CreateTermSet($newTermSetName, [System.Guid]::NewGuid(), 1033)
        $ctx.ExecuteQuery()
    }

    # Recursive function to create terms
    function Create-TermHierarchy {
        param(
            [Parameter(Mandatory = $true)] $terms,
            $parentTerm
        )
        foreach ($term in $terms) {
            try {
                if ($parentTerm) {
                    $ctx.Load($parentTerm)
                    $ctx.ExecuteQuery()
                    $newTerm = $parentTerm.CreateTerm($term.Name, 1033, [System.Guid]::NewGuid())
                    $newTerm.SetLocalCustomProperty("ParentId", $parentTerm.Id.ToString())
                } else {
                    $newTerm = $termSet.CreateTerm($term.Name, 1033, [System.Guid]::NewGuid())
                    $newTerm.SetLocalCustomProperty("ParentId", $termSet.Id.ToString())
                }

                # Apply metadata
                if ($term.Description) { $newTerm.SetDescription($term.Description, 1033) }

                # Custom Properties
                if ($term.CustomProperties) {
                    foreach ($key in $term.CustomProperties.PSObject.Properties.Name) {
                        $newTerm.SetCustomProperty($key, $term.CustomProperties[$key])
                    }
                }

                 # Local Custom Properties
if ($term.LocalCustomProperties -and $term.LocalCustomProperties.PSObject.Properties.Count -gt 0) {
    foreach ($key in $term.LocalCustomProperties.PSObject.Properties.Name) {
    if ($key -ne "ParentId") {
    $newTerm.SetLocalCustomProperty($key, $term.LocalCustomProperties.PSObject.Properties[$key].Value)
        #$newTerm.SetLocalCustomProperty($key, $term.LocalCustomProperties[$key])
    }
    }
    $newTerm.Context.ExecuteQuery()
    
}

                $ctx.ExecuteQuery()
                $ctx.Load($newTerm)
                $ctx.ExecuteQuery()
                Write-Log "Created term: $($term.Name) ID: $($newTerm.Id)"

                # Recursively create children
                if ($term.Children -and $term.Children.Count -gt 0) {
                    Create-TermHierarchy -terms $term.Children -parentTerm $newTerm
                }
            } catch {
                Write-Log "Failed to create term: $($term.Name). Error: $_" "ERROR"
            }
        }
    }

    # Start creating terms
    Write-Log "Starting term hierarchy creation..."
    Create-TermHierarchy -terms $terms -parentTerm $null
    Write-Log "✅ Nested term set imported successfully."

} catch {
    Write-Log "❌ Critical Error: $_" "ERROR"
    Write-Host "An error occurred. Check log file: $LogFilePath"
}