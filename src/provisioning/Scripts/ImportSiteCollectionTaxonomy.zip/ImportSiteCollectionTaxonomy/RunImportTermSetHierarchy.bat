@echo off
REM Change directory to script location
cd /d "C:\Projects\MADB_PowerShellScripts\ImportSiteCollectionTaxonomy"

REM Run PowerShell script with parameters
powershell.exe -ExecutionPolicy Bypass -File "ImportTermSet.ps1" ^
    -SiteUrl "https://eutelsatgroup.sharepoint.com/sites/MADB-Dev" ^
    -InputJsonPath "%~dp0..\ExportSiteCollectionTaxonomy\ExportTermSetHierarchy.json" ^
    -LogFilePath "%~dp0ImportTermSet.log"

pause